1. Make a base test for all test
2. Try to make many TestNG file for multiple scenario
